This readme file explains how to use the compiled Windows executable called themerandom.exe

1. You should have received/downloaded an archive called themerandom_windows_es.zip
2. The archive should contain this readme file, a compiled AutoHotkey file called themerandom.exe, and a themerandom.ini file.
3. You need to modify the themerandom.ini file to include two paths which matches to your Emulation Station for Windows installation.
4. Edit themerandom.ini with any convenient text editor.
5. Find the first line to edit: ThemeHomeDir=
6. Append the full path to your Emulation Station themes directory.
7. An example of the finished line may be:
	ThemeHomeDir=D:\Games\Portable_Game_Station_1.5\.emulationstation\themes
8. Find the second line to edit: ESConfig=
9. Append the full path to your Emulation Station configuration file.
10. An example of the finished line may be:
	D:\Games\Portable_Game_Station_1.5\.emulationstation\es_settings.cfg
11. Find the DOS batch file that starts your Emulation Station program.
12. Edit the batch file from step 11 and add the following line in front of the line that starts emulationstation.exe
	themerandom.exe
13. An example of the finished batch file would be:
	set HOME=%~dp0
	themerandom.exe
	emulationstation.exe
14. Save the edited batch file and place the files listed in step 2 above in the same directory as the batch file from step 11 above.
